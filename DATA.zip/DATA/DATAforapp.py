#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan  6 11:32:48 2020

@author: macbookpro
"""

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib as mpl
import matplotlib.pyplot as plt


import plotly.tools as tls
import plotly as py
import plotly.graph_objs as go
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
from chart_studio import plotly as py
from plotly.offline import iplot


df = pd.read_csv("/Users/macbookpro/Desktop/DATA/Transport2.csv")
df2 = pd.read_csv("/Users/macbookpro/Desktop/DATA/services1.csv")
df.head()
print(df.head())
print(df2.head())
print(df.describe(include='all'))
print(df['Région'])





objects = ('Agadir', 'Rabat', 'Casablanca', 'Tanger', 'Oujda')
y_pos = np.arange(len(objects))
performance = [54839,75117,436800,123233,64252]
plt.bar(y_pos, performance, align='center', alpha=0.5)
plt.xticks(y_pos, objects)
plt.ylabel('CO2 footprint')
plt.title('Région')
plt.show()

objects = ('Agadir', 'Rabat', 'Casablanca', 'Tanger', 'Oujda')
y_pos = np.arange(len(objects))
performance = [15355,21032,122304,34505,17990]
plt.bar(y_pos, performance, align='center', alpha=0.5)
plt.xticks(y_pos, objects)
plt.ylabel('CO2 transportation')
plt.title('Région')
plt.show()


objects = ('Agadir', 'Casablanca', 'Oujda', 'Rabat', 'Tanger')
y_pos = np.arange(len(objects))
performance = [24129, 192192 ,28271,33051,54222]
plt.bar(y_pos, performance, align='center', alpha=0.5)
plt.xticks(y_pos, objects)
plt.ylabel('Service emission')
plt.title('Région')
plt.show()


objects = ('Agadir', 'Casablanca', 'Oujda', 'Rabat', 'Tanger')
y_pos = np.arange(len(objects))
performance = [3838,30576,4497,5258,8626]
plt.bar(y_pos, performance, align='center', alpha=0.5)
plt.xticks(y_pos, objects)
plt.ylabel('Energy emission ')
plt.title('Région')
plt.show()







